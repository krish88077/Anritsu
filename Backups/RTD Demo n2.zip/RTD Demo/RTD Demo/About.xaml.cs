﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RTD_Demo
{
    /// <summary>
    /// Interaction logic for About.xaml
    /// </summary>
    public partial class About : Window
    {
        public About()
        {
            InitializeComponent();
        }


        private void buttonClose_Click(object sender, RoutedEventArgs e)
        {
            // Shutdown current application
            this.Close();
        }

        private void labelApplicationTitle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Maximize or restore window if left button is clicked two times
            // Allow window to be dragged if left button is clicked and hold only one time
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }
    }
}
