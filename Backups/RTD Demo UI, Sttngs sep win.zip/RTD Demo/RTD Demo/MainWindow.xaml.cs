﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using ExcelLibrary.SpreadSheet;
using ExcelLibrary.CompoundDocumentFormat;
using System.IO;
using Microsoft.Win32;
using System.Data.OleDb;
using System.Data;
using System.Security.Principal;
using System.Windows.Threading;

namespace RTD_Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string path = @"../../RTD PRR2.xlsx";
        string openSheet = "RTD_Patch_Releases _- _OPEN";
        string patchSheet = "Patch_Number_For_Component";
        OleDbDataAdapter da1, da2;
        DataTable[] dt = new DataTable[10];
        DataView[] view = new DataView[5];
        int count = 0, count1 = 0, count2 = 0;
        DispatcherTimer timer = null;

        public MainWindow()
        {
            InitializeComponent();
            Search_Expander.IsExpanded = false;
            Filter_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
            string user = WindowsIdentity.GetCurrent().Name;
            string[] strArr = user.Split('\\');
            string sub = strArr[1];
            userlbl.Content = sub;

            this.Hide();
            Startscreen sw = new Startscreen();
            sw.Show();
            StartTimer();

        }
        void StartTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(4);
            timer.Tick += new EventHandler(timer_Elapsed);
            timer.Start();
        }
        void timer_Elapsed(object sender, EventArgs e)
        {
            timer.Stop();
            this.Show();
        }

        private void clear_all()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();
            comboBox1.Items.Add("--Component_name--");
            comboBox2.Items.Add("--RTD Patch series--");
            comboBox3.Items.Add("--RTD Version--");
            count = 0; count1 = 0; count2 = 0;
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 0;
        }

        private void Search_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            clear_all();
            Filter_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
        }

        private void Filter_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            Search_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
            Resulttab.IsSelected = false;
            Logstab.IsSelected = true;
        }

        private void Settings_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            Search_Expander.IsExpanded = false;
            Filter_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
            Resulttab.IsSelected = false;
            Logstab.IsSelected = true;
        }

        private void Info_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            Search_Expander.IsExpanded = false;
            Filter_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Resulttab.IsSelected = false;
            Logstab.IsSelected = true;
        }




        string logtxt = "";

        private void Load_new_excel(object sender, RoutedEventArgs e)
        {
            var obj = new LoadExcel();
            obj.ShowDialog();
            this.Show();


            string fileName = obj.patht;
            try
            {

                string sheet = "Sheet1";
                string pathcon = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + fileName + ";Extended Properties=Excel 12.0;";
                OleDbConnection conn = new OleDbConnection(pathcon);
                OleDbDataAdapter da = new OleDbDataAdapter("Select * from [" + sheet + "$] ", conn);

                System.Data.DataTable dt = new System.Data.DataTable();

                da.Fill(dt);
                dataGrid_cmbodisp.ItemsSource = dt.DefaultView;
                dataGrid_cmbodisp.AutoGenerateColumns = true;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
                Resulttab.IsSelected = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select a file...");
            }


        }


        private void Filterbtn_Click(object sender, RoutedEventArgs e)
        {
            dataGrid_disp.ItemsSource = null;

            string sheet = "RTD_Patch_Releases_-_CLOSED";
            string pathcon = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + path + ";Extended Properties=Excel 12.0;";
            OleDbConnection conn = new OleDbConnection(pathcon);
            OleDbDataAdapter da;

            //if ((chkbx1.IsChecked == true) && (chkbx2.IsChecked == false) && (chkbx3.IsChecked == false) )
            //{
            //    da = new OleDbDataAdapter("Select Status from [" + sheet + "$] ", conn);
            //}
            //else if ((chkbx1.IsChecked == true) && (chkbx2.IsChecked == true))
            //{
            //    da = new OleDbDataAdapter("Select Status , Created_by from [" + sheet + "$] ", conn);
            //}
            //else if (chkbx1.IsChecked == true)
            //{
            //    da = new OleDbDataAdapter("Select Status from [" + sheet + "$] ", conn);
            //}
            //else if (chkbx2.IsChecked == true)
            //{
            //    da = new OleDbDataAdapter("Select Created_by from [" + sheet + "$] ", conn);
            //}
            //else if (chkbx3.IsChecked == true)
            //{
            //    da = new OleDbDataAdapter("Select Bug_Feature_or_both from [" + sheet + "$] ", conn);
            //}
            //else
            da = new OleDbDataAdapter("Select Status from [" + sheet + "$] ", conn);


            System.Data.DataTable dt3 = new System.Data.DataTable();

            da.Fill(dt3);
            dataGrid_disp.ItemsSource = dt3.DefaultView;
            dataGrid_disp.AutoGenerateColumns = true;


            logtxt = "Filtering the database...";
            //Logs.Text = logtxt + DateTime.Now.ToString("hh:mm:ss tt");
            Logs.AppendText(Environment.NewLine + logtxt + DateTime.Now.ToString("hh:mm:ss tt"));
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            openSheetLoad();
            patchSheetLoad();
        }

        public void openSheetLoad()
        {
            dataGrid_disp.ItemsSource = null;
            string pathcon1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + path + ";Extended Properties=Excel 12.0;";
            OleDbConnection conn1 = new OleDbConnection(pathcon1);
            da1 = new OleDbDataAdapter("Select * from [" + openSheet + "$] ", conn1);
            dt[0] = new System.Data.DataTable();
            da1.Fill(dt[0]);
            dataGrid_disp.ItemsSource = dt[0].DefaultView;
            dataGrid_disp.AutoGenerateColumns = true;
            dataGrid_disp.MinColumnWidth = 100;
            dataGrid_disp.MaxColumnWidth = 250;

            dt[1] = new System.Data.DataTable();
            dt[1] = dt[0];
        }

        public void patchSheetLoad()
        {
            string pathcon2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + path + ";Extended Properties=Excel 12.0;";
            OleDbConnection conn2 = new OleDbConnection(pathcon2);
            da2 = new OleDbDataAdapter("Select * from [" + patchSheet + "$] ", conn2);
            dt[2] = new System.Data.DataTable();
            da2.Fill(dt[2]);
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dt[3] = new System.Data.DataTable();
            view[0] = new DataView(dt[2]);
            dt[3] = view[0].ToTable("dt[3]", false, "Component_name");

            if (count == 0)
                foreach (DataRow row in dt[3].Rows)
                {
                    comboBox1.Items.Add(row["Component_name"]);

                }
            count++;
            for (int i = 0; i < 10; i++)
            {
                if (comboBox1.SelectedIndex == i)
                {
                    comboBox2.SelectedIndex = i;
                    break;
                }
            }
        }

        private void comboBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dt[4] = new System.Data.DataTable();
            view[1] = new DataView(dt[2]);
            dt[4] = view[1].ToTable("dt[4]", false, "Component_name", "Patch_Number_Allocation");

            if (count1 == 0)
                foreach (DataRow row in dt[4].Rows)
                {
                    comboBox2.Items.Add(row["Patch_Number_Allocation"]);

                }
            count1++;
            for (int i = 0; i < 10; i++)
            {
                if (comboBox2.SelectedIndex == i)
                {
                    comboBox1.SelectedIndex = i;

                    break;
                }
            }
            comboBox3SetData();
        }

        public void comboBox3SetData()
        {
            if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 0)
            {
                comboBox3.Items.Clear();
                comboBox3.Items.Insert(0, "--RTD Version--");
                comboBox3.SelectedIndex = 0;
                count2 = 0;
            }
            else if (comboBox3.SelectedIndex > 0) { }
            else if (comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0)
            {
                comboBox3.Items.Clear();

                dt[5] = new System.Data.DataTable();
                view[2] = new DataView(dt[1]);
                dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");

                comboBox3.Items.Clear();

                //int count = 0;
                try
                {
                    string str = null, str1;
                    comboBox3.Items.Add("--RTD Version--");
                    comboBox3.SelectedIndex = 0;
                    foreach (DataRow row in dt[5].Rows)
                    {

                        str = row["Patch_name"].ToString();
                        str1 = comboBox2.SelectedItem.ToString();
                        string[] strArr = str.Split(' ');
                        int len = strArr.Length;
                        string[] strArr1 = str1.Split(' ');
                        string sub = strArr[len - 1].Substring(0, 2);
                        string sub1 = sub.Substring(1, 1);


                        if (sub.StartsWith(strArr1[0]))
                        {
                            if (strArr1[0] == "10")
                            {
                                comboBox3.Items.Add(row["Patch_name"]);
                            }
                            else if (sub.StartsWith("1"))
                            {
                                if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                                {
                                    comboBox3.Items.Add(row["Patch_name"]);
                                }
                            }

                            else
                            {
                                comboBox3.Items.Add(row["Patch_name"]);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                }

            }
        }

        private void comboBox3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 0)
            {
                dt[6] = new System.Data.DataTable();
                view[3] = new DataView(dt[1]);
                dt[6] = view[3].ToTable("dt[6]", false, "Patch_name");

                if (count2 == 0)
                    foreach (DataRow row in dt[6].Rows)
                    {
                        comboBox3.Items.Add(row["Patch_name"]);
                    }
                count2++;
            }

            if (comboBox3.SelectedIndex > 0)
            {
                comboBox1_2SetData();
            }
        }

        public void comboBox1_2SetData()
        {
            dt[7] = new System.Data.DataTable();
            view[4] = new DataView(dt[2]);
            dt[7] = view[4].ToTable("dt[7]", false, "Component_name", "Patch_Number_Allocation");

            try
            {
                string str = null, str1;
                foreach (DataRow row in dt[7].Rows)
                {

                    str = row["Patch_Number_Allocation"].ToString();
                    str1 = comboBox3.SelectedItem.ToString();
                    string[] strArr = str.Split(' ');
                    string[] strArr1 = str1.Split(' ');
                    int len = strArr1.Length;
                    string sub = strArr1[len - 1].Substring(0, 2);
                    string sub1 = sub.Substring(1, 1);


                    if (sub.StartsWith(strArr[0]) || sub.StartsWith("7") || sub.StartsWith("x"))
                    {
                        if (sub.StartsWith("7") || sub.StartsWith("x"))
                        {
                            comboBox1.Items.Add("NA");
                            comboBox2.Items.Add("NA");
                            comboBox1.SelectedValue = "NA";
                            comboBox2.SelectedValue = "NA";
                        }
                        else if (strArr[0] == "10")
                        {
                            comboBox2.SelectedItem = row["Patch_Number_Allocation"];
                        }

                        else if (sub.StartsWith("1"))
                        {
                            if ((sub1.Contains("1")) || (sub1.Contains("2")) || (sub1.Contains("3")) || (sub1.Contains("4")) || (sub1.Contains("5")) || (sub1.Contains("6")) || (sub1.Contains("7")) || (sub1.Contains("8")) || (sub1.Contains("9")))
                            {
                                comboBox1.Items.Add("NA");
                                comboBox2.Items.Add("NA");
                                comboBox1.SelectedValue = "NA";
                                comboBox2.SelectedValue = "NA";
                            }
                            if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                            {
                                comboBox2.SelectedItem = row["Patch_Number_Allocation"];
                            }
                        }

                        else
                        {
                            comboBox2.SelectedItem = row["Patch_Number_Allocation"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            /********************** RESULT FOUND*******************/
            try
            {
                Resulttab.IsSelected = true;
                if (comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0 && comboBox3.SelectedIndex > 0)
                {
                    string item = comboBox3.SelectedItem.ToString();
                    dt[8] = new System.Data.DataTable();
                    dt[8] = dt[1].Select("Patch_name='" + item + "'").CopyToDataTable();
                    dataGrid_cmbodisp.ItemsSource = dt[8].DefaultView;
                    dataGrid_cmbodisp.CanUserAddRows = false;
                    dataGrid_cmbodisp.MinColumnWidth = 100;
                    dataGrid_cmbodisp.MaxColumnWidth = 250;
                    //clear_all();
                }
                else if (comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0)
                {
                    dt[9] = dt[1].Clone();
                    for (int i = 1; i < comboBox3.Items.Count; i++)
                    {
                        comboBox3.SelectedIndex = i;
                        string item = comboBox3.SelectedItem.ToString();
                        DataRow[] rowsToCopy;
                        rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                        foreach (DataRow temp in rowsToCopy)
                        {
                            dt[9].ImportRow(temp);
                        }

                        dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                        dataGrid_cmbodisp.CanUserAddRows = false;
                        dataGrid_cmbodisp.MinColumnWidth = 100;
                        dataGrid_cmbodisp.MaxColumnWidth = 250;
                    }
                    comboBox3.SelectedIndex = 0;
                    //clear_all();
                }
                else
                    MessageBox.Show("Select all the items..");
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        

        private void Aboutbtn_Click(object sender, RoutedEventArgs e)
        {
            About ab = new About();
            ab.ShowDialog();
        }

        private void Helpbtn_Click(object sender, RoutedEventArgs e)
        {
            Help h = new Help();
            h.ShowDialog();
        }

        private void Feedbackbtn_Click(object sender, RoutedEventArgs e)
        {
            Feedback fb = new Feedback();
            fb.ShowDialog();
        }

        private void Series1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S1 Clicked...");
        }

        private void Series2_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S2 Clicked...");
        }

        private void Series3_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S3 Clicked...");
        }

        private void Series4_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S4 Clicked...");
        }

        private void Series5_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S5 Clicked...");
        }

        private void Series6_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S6 Clicked...");
        }

        private void Series8_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S8 Clicked...");
        }

        private void Series9_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S9 Clicked...");
        }

        private void Series10_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("S10 Clicked...");
        }

        

      

        private void ClearAll_btn_Click(object sender, RoutedEventArgs e)
        {
            dataGrid_cmbodisp.ItemsSource = null;
            clear_all();
        }

        private void Export_btn_Click(object sender, RoutedEventArgs e)
        {
            //dataGrid_cmbodisp.SelectAllCells();
            //dataGrid_cmbodisp.ClipboardCopyMode = DataGridClipboardCopyMode.IncludeHeader;
            //ApplicationCommands.Copy.Execute(null, dataGrid_cmbodisp);
            //String result = (string)Clipboard.GetData(DataFormats.CommaSeparatedValue);
            //dataGrid_cmbodisp.UnselectAllCells();

            //string path = @"E:\\zz.xls";



            //System.IO.StreamWriter file1 = new System.IO.StreamWriter(@path);

            //file1.WriteLine(result);
            //file1.Close();

            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            worksheet.Name = "Exported data";


            for (int i = 1; i < dataGrid_cmbodisp.Columns.Count + 1; i++ )
            {
                worksheet.Cells[1, i] = dataGrid_cmbodisp.Columns[i - 1].Header;
            }

            for (int i = 0; i < dataGrid_cmbodisp.Items.Count;i++ )
            {
                for (int j = 0; j < dataGrid_cmbodisp.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = (dataGrid_cmbodisp.Items[i] as DataRowView).Row.ItemArray[j].ToString();
                }
            }

            worksheet.Columns.AutoFit();
            worksheet.Rows.AutoFit();

            var sfd = new SaveFileDialog();
            //sfd.FileName = "QQQ";
            sfd.DefaultExt = ".xlsx";
            if(sfd.ShowDialog() == true)
            {
                workbook.SaveAs(sfd.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            }
            app.Quit();
        }

        private void Expandviewtbn_Click(object sender, RoutedEventArgs e)
        {
            var obj2 = new Filtered_data();
            obj2.dataGrid1.ItemsSource = dataGrid_cmbodisp.Items;
            obj2.ShowDialog();
            
        }

        private void buttonMinimize_Click(object sender, RoutedEventArgs e)
        {
            // Set Window State to Minimized
            this.WindowState = WindowState.Minimized;
        }

        

        private void buttonClose_Click(object sender, RoutedEventArgs e)
        {
            // Shutdown current application
            Application.Current.Shutdown();
        }

        private void labelApplicationTitle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Maximize or restore window if left button is clicked two times
            // Allow window to be dragged if left button is clicked and hold only one time
            if (e.ChangedButton == MouseButton.Left)
            {
                if (e.ClickCount == 2)
                {
                    this.WindowState = this.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
                }
                else
                {
                    Application.Current.MainWindow.DragMove();
                }
            }
        }
       
    }
}
