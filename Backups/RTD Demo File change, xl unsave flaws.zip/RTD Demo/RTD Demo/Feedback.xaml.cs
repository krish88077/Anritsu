﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

using Outlook = Microsoft.Office.Interop.Outlook;
using System.Diagnostics;

namespace RTD_Demo
{
    /// <summary>
    /// Interaction logic for Feedback.xaml
    /// </summary>
    public partial class Feedback : Window
    {

        string logtxt = "";
        string logtime = "";
        string logfuncname = "";
        logger logobj = logger.getInstance();
        public string s;

        public Feedback()
        {
            InitializeComponent();
        }

        public string getCallFunName()
        {
            StackFrame frame = new StackFrame(1);
            var method = frame.GetMethod();
            var type = method.DeclaringType.Name;
            var name = method.Name;
            string classname = type + "." + name;
            return classname;
        }


        private void labelApplicationTitle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Maximize or restore window if left button is clicked two times
            // Allow window to be dragged if left button is clicked and hold only one time
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        private void Clsbtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        string fileName = "";
        string fnwithoutpath = "";
        private void Browsebtn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog oo = new OpenFileDialog();

            
            if (oo.ShowDialog() == true)
            {
                fileName = oo.FileName;
                Attach_path.Text = fileName;
                fnwithoutpath = System.IO.Path.GetFileName(oo.FileName);
            }
        }

        private void Sendbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Create the Outlook application.
                Outlook.Application oApp = new Outlook.Application();
                // Create a new mail item.
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                // Set HTMLBody. 
                //add the body of the email
                oMsg.HTMLBody = Fdbk_tbk.Text;
                //Add an attachment.
                String sDisplayName = System.IO.Path.GetFileName(fnwithoutpath);
                int iPosition = (int)oMsg.Body.Length + 1;
                int iAttachType = (int)Outlook.OlAttachmentType.olByValue;
                //now attached the file
                Outlook.Attachment oAttach = oMsg.Attachments.Add(fileName, iAttachType, iPosition, sDisplayName);
                //Subject line
                oMsg.Subject = "Feedback";
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                // Change the recipient in the next line if necessary.
                Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add("krishgsmiley@gmail.com");
                oRecip.Resolve();
                // Send.
                oMsg.Send();
                // Clean up.
                oRecip = null;
                oRecips = null;
                oMsg = null;
                oApp = null;

                if (Fdbk_tbk.Text != "")
                {
                    logtxt = "Feedback has been sent to the Developer";
                    logfuncname = getCallFunName();
                    logtime = logobj.logFeedback(logtxt, logfuncname);
                    s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt);
                }

            }//end of try block
            catch (Exception ex)
            {
            }
            this.Close();
        }

    
       

       
    }
}
