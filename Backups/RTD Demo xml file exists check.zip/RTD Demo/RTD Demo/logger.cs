﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;

namespace RTD_Demo
{
    class logger
    {
        private static System.IO.StreamWriter _Output = null;
        private static logger _logger = null;

        public static string _LogFile = @"C:\RTD\Logs\Adminlogs.log";
        string logtime = "";
        string funcName = "";
        private logger()
        {

        }

        public string getCallFunName()
        {
            StackFrame frame = new StackFrame(1);
            var method = frame.GetMethod();
            var type = method.DeclaringType.Name;
            var name = method.Name;
            string classname = type + "." + name;
            return classname;
        }

        public static logger getInstance()
        {

            string path1 = @"c:\RTD\Logs"; // or whatever  
            if (!Directory.Exists(path1))
            {
                Directory.CreateDirectory(path1);
            }

            var files = new DirectoryInfo(@"c:\RTD\Logs").GetFiles("*.log");
            foreach (var file in files)
            {
                if (DateTime.UtcNow - file.CreationTimeUtc > TimeSpan.FromDays(1))
                {
                    File.SetCreationTimeUtc(_LogFile,DateTime.UtcNow);
                    File.Create(file.FullName);
                }
            }

            //lock object to make it thread safe  

            if (_logger == null)
            {
                _logger = new logger();
                //MessageBox.Show("Instance Created...");
            }

            return _logger;
        }


        public string logUser(string logtxt, string logfuncname)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");
                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                
                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + logfuncname + " Calls " + funcName);

                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logRead(int logcount, string logtxt, string logfuncname, string logruntime)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");
                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                
                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " and " + logcount + " Entries are Imported to Tool" + " | " + logfuncname + " Calls " + funcName + " | " + "Runtime: " + logruntime + "ms");

                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logSwitch(string logtxt, string logfuncname)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");
                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + logfuncname + " Calls " + funcName);

                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logLoadExcel(int logcount, string logtxt, string logfuncname, string logruntime)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + " No of Entries found: " + logcount + " | " + logfuncname + " Calls " + funcName + " | " + "Runtime: " + logruntime + "ms");


                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logLoadExcelError(string logtxt, string logfuncname)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + logfuncname + " Calls " + funcName);

                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logSearch(int logcount, string logtxt, string logfuncname, string logruntime)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + " No of Entries found: " + logcount + " | " + logfuncname + " Calls " + funcName + " | " + "Runtime: " + logruntime + "ms");


                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logFilter(int logcount, string logtxt, string logfuncname, string logruntime)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + " No of Entries found: " + logcount + " | " + logfuncname + " Calls " + funcName + " | " + "Runtime: " + logruntime + "ms");


                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logFilter1(string logtxt, string logfuncname)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + logfuncname + " Calls " + funcName);


                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logExportdg(int logcount, string logtxt, string logfuncname, string logruntime)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + " No of Entries found: " + logcount + " | " + logfuncname + " Calls " + funcName + " | " + "Runtime: " + logruntime + "ms");


                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logExportlogs(string logtxt, string logfuncname)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + logfuncname + " Calls " + funcName);

                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }


        public string logFeedback(string logtxt, string logfuncname, string logruntime)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + logfuncname + " Calls " + funcName + " | " + "Runtime: " + logruntime + "ms");

                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }

        public string logSeries(int logcount, string logtxt, string logfuncname, string logruntime)
        {
            try
            {
                logtime = System.DateTime.Now.ToString("HH:mm:ss");

                funcName = getCallFunName();

                if (_Output == null)
                {
                    _Output = new System.IO.StreamWriter(_LogFile, true, System.Text.UnicodeEncoding.Default);
                }

                _Output.WriteLine("[ " + logtime + " ] " + logtxt + " | " + " No of Entries found: " + logcount + " | " + logfuncname + " Calls " + funcName + " | " + "Runtime: " + logruntime + "ms");


                if (_Output != null)
                {
                    _Output.Close();
                    _Output = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, new object[0]);
            }
            return logtime;
        }
    }
}
