﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using ExcelLibrary.SpreadSheet;
using ExcelLibrary.CompoundDocumentFormat;
using System.IO;
using Microsoft.Win32;
using System.Data.OleDb;
using System.Data;
using System.Security.Principal;
using System.Windows.Threading;
using System.Xml;
using System.Diagnostics;

namespace RTD_Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string path = @"../../Excel/RTD Patch Release Register.xlsx";
        string xmlpath = @"../../Xml/RTD Permission Details.xml";
        string openSheet = "RTD_Patch_Releases_-_OPEN";
        string patchSheet = "Patch_Number_For_Component";
        OleDbDataAdapter da1, da2;
        DataTable[] dt = new DataTable[18];
        DataView[] view = new DataView[9];
        int count = 0, count1 = 0, count2 = 0;
        DispatcherTimer timer = null;
        public string fileName;

        int logcount;
        string logtxt = "";
        string logtime = "";
        string logfuncname = "";
        logger logobj = logger.getInstance();
        

        public MainWindow()
        {
            InitializeComponent();
            Style = (Style)FindResource(typeof(Window));
            Search_Expander.IsExpanded = false;
            Filter_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
            string user = WindowsIdentity.GetCurrent().Name;
            string[] strArr = user.Split('\\');
            string sub = strArr[1];
            userlbl.Content = sub;

            this.Hide();
            Startscreen sw = new Startscreen();
            sw.Show();
            StartTimer(4);

        }

        public void winViewOnErrorFile()
        {
            Search_Expander.IsEnabled = false;
            Filter_Expander.IsEnabled = false;
            Info_Expander.IsEnabled = false;
            Series1.IsEnabled = false;
            Series2.IsEnabled = false;
            Series3.IsEnabled = false;
            Series4.IsEnabled = false;
            Series5.IsEnabled = false;
            Series6.IsEnabled = false;
            Series8.IsEnabled = false;
            Series9.IsEnabled = false;
            Series10.IsEnabled = false;
            Settings_Expander.BorderBrush = Brushes.Gray;
            Settings_Expander.Background = (Brush)FindResource("Appbg");
        }

        void StartTimer(int sec)
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(sec);
            if(sec==4)
            timer.Tick += new EventHandler(timer_Elapsed);
            else
                timer.Tick += new EventHandler(timer_Elapsed1);
            timer.Start();
        }
        void timer_Elapsed1(object sender, EventArgs e)
        {
            App.Current.Shutdown();
        }
        void timer_Elapsed(object sender, EventArgs e)
        {
            timer.Stop();
            this.Show();
            if (!(System.IO.File.Exists(path)))
            {
                var Fileobj = new ExcepWindow();
                Fileobj.msg = "Patch Register File does not Exist.";
                Fileobj.ShowDialog();
                winViewOnErrorFile();
            }
            if (!(System.IO.File.Exists(xmlpath)))
            {
                var Fileobj = new ExcepWindow();
                Fileobj.msg = "Permission File does not Exist. RTD tool is going to shutdown.";
                Fileobj.ShowDialog();
                StartTimer(2);
            }
        }

        public string getCallFunName()
        {
            StackFrame frame = new StackFrame(1);
            var method = frame.GetMethod();
            var type = method.DeclaringType.Name;
            var name = method.Name;
            string classname = type + "." + name;
            return classname;
        }

        private void clear_all()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();
            comboBox1.Items.Add("Component_name");
            comboBox2.Items.Add("RTD Patch series");
            comboBox3.Items.Add("RTD Version");
            count = 0; count1 = 0; count2 = 0;
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 0;
        }

        public void Button_enable()
        {
            Expandviewtbn.IsEnabled = true;
           
        }

        private void Button_disable()
        {
            Expandviewtbn.IsEnabled = false;
           
        }

        private void Search_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            clear_all();
            Filter_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
            Resulttab.IsSelected = false;
            Logstab.IsSelected = true;
            dataGrid_cmbodisp.ItemsSource = null;
            treeviewexpander_close();
        }

        private void Filter_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            Filter_Expander.Expanded += new RoutedEventHandler(Resetbtn_Click);
            Search_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
            Resulttab.IsSelected = false;
            Logstab.IsSelected = true;
            filterInit();
            dataGrid_cmbodisp.ItemsSource = null;
            treeviewexpander_close();
        }

        private void Settings_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            Search_Expander.IsExpanded = false;
            Filter_Expander.IsExpanded = false;
            Info_Expander.IsExpanded = false;
            Resulttab.IsSelected = false;
            Logstab.IsSelected = true;
            treeviewexpander_close();
        }

        private void Info_Expander_Expanded(object sender, RoutedEventArgs e)
        {
            Search_Expander.IsExpanded = false;
            Filter_Expander.IsExpanded = false;
            Settings_Expander.IsExpanded = false;
            Resulttab.IsSelected = false;
            Logstab.IsSelected = true;
            treeviewexpander_close();
        }

        public void treeviewexpander_close()
        {
            if (customerItem.Visibility == System.Windows.Visibility.Visible)
            {
                customerItem.IsExpanded = false;
            }
            statusItem.IsExpanded = false;
            ownerItem.IsExpanded = false;
            bugFeatureItem.IsExpanded = false;
            
        }

        public void winstart(int chk)
        {
            string h = WindowsIdentity.GetCurrent().Name;
            string[] strArr = h.Split('\\');
            string sub = strArr[1];
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(xmlpath);
            XmlNodeList nodeList = xmldoc.SelectNodes("/Userdetails/User[Name='" + sub + "']");
            if (chk == 0)
            {
                logtxt = "User Logged in as " + sub;
                logfuncname = getCallFunName();
                logtime = logobj.logUser(logtxt, logfuncname);
                //Logs.Foreground = new SolidColorBrush(Colors.Blue);
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
            if (System.IO.File.Exists(path))
            {
                string sql = "Patch_name,Brief_description,RTD_version,Status,Bug_feature_or_both,Owner";
                foreach (XmlNode node in nodeList)
                {
                    if (node["Mode"].Attributes["FCntrl"].Value == "true")
                    {
                        FCtrl_modebtn.Visibility = System.Windows.Visibility.Visible;
                        customerItem.Visibility = System.Windows.Visibility.Collapsed;
                        //sql = node["FCtrlsql"].Attributes["qry"].Value;
                        //if (node["Perm"].Attributes["Write"].Value == "true")
                        //{
                        //    dataGrid_disp.IsReadOnly = false;
                        //    dataGrid_cmbodisp.IsReadOnly = false;
                        //}
                    }
                    else
                    {
                        sql = node["RCtrlsql"].Attributes["qry"].Value;
                    }
                }
                openSheetLoad(sql, chk);
                patchSheetLoad();
            }
        }
        
        private void Load_new_excel(object sender, RoutedEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            var ldxl = new LoadExcel();
            ldxl.ShowDialog();
            this.Show();
            int chk = 1;
            if (ldxl.loadChk!=0)
            {
                fileName = ldxl.patht;
                path = fileName;
                string fnwithoutpath = System.IO.Path.GetFileName(path);
                try
                {
                    Search_Expander.IsEnabled = true;
                    Filter_Expander.IsEnabled = true;
                    Info_Expander.IsEnabled = true;
                    Series1.IsEnabled = true;
                    Series2.IsEnabled = true;
                    Series3.IsEnabled = true;
                    Series4.IsEnabled = true;
                    Series5.IsEnabled = true;
                    Series6.IsEnabled = true;
                    Series8.IsEnabled = true;
                    Series9.IsEnabled = true;
                    Series10.IsEnabled = true;
                    Settings_Expander.IsExpanded = false;
                    Settings_Expander.BorderBrush = Brushes.Transparent;
                    Settings_Expander.Background = Brushes.Transparent;

                    winstart(chk);
                    dataGrid_cmbodisp.ItemsSource = null;
                    Logstab.IsSelected = true;
                    Resulttab.IsSelected = false;

                    watch.Stop();
                    var elapsedMs = watch.ElapsedMilliseconds;
                    //MessageBox.Show(elapsedMs.ToString());
                    string logPath = System.IO.Path.GetDirectoryName(fileName);
                    logtxt = "New RTD File Loaded from " + logPath;
                    logcount = dataGrid_disp.Items.Count;
                    logfuncname = getCallFunName();
                    logtime = logobj.logLoadExcel(logcount, logtxt, logfuncname, elapsedMs.ToString());
                    string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and " + logcount + " Entries are Imported to Tool");

                    TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                    rangeOfWord.Text = s;
                    rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                    rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);

                    Fetchtab.IsSelected = true;
                    FCtrl_modebtn.IsEnabled = true;
                }
                catch (Exception ex)
                {
                    if (ex.Message != "Invalid argument.")
                    {
                        winViewOnErrorFile();
                        FCtrl_modebtn.Visibility = System.Windows.Visibility.Collapsed;

                        var excp = new ExcepWindow();
                        excp.msg = "Loaded File is not in Expected Format. See logs for further details.";
                        excp.ShowDialog();

                        logtxt = fileName + " , " + ex.Message;
                        logfuncname = getCallFunName();
                        logtime = logobj.logLoadExcelError(logtxt, logfuncname);
                        string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt);

                        TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                        rangeOfWord.Text = s;
                        rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, Brushes.Red);
                        rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
                    }
                    else
                    {
                        var excp = new ExcepWindow();
                        excp.msg = ex.Message;
                        excp.ShowDialog();
                    }
                }

            }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            int chk = 0;
            winstart(chk);
        }

        public void openSheetLoad(string sql, int chk)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            dataGrid_disp.ItemsSource = null;
            string pathcon1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + path + ";Extended Properties=Excel 12.0;";
            OleDbConnection conn1 = new OleDbConnection(pathcon1);
            da1 = new OleDbDataAdapter("Select " + sql + " from [" + openSheet + "$] ", conn1);
            dt[0] = new System.Data.DataTable();
            da1.Fill(dt[0]);
            dataGrid_disp.ItemsSource = dt[0].DefaultView;

            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            if (chk == 0)
            {
                logtxt = "Reading RTD File from " + path;
                logcount = dataGrid_disp.Items.Count;
                logfuncname = getCallFunName();
                logtime = logobj.logRead(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and " + logcount + " Entries are Imported to Tool");

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }

            dataGrid_disp.AutoGenerateColumns = true;
            dataGrid_disp.MinColumnWidth = 100;
            dataGrid_disp.MaxColumnWidth = 250;

            dt[1] = new System.Data.DataTable();
            dt[1] = dt[0];
        }

        public void patchSheetLoad()
        {
            string pathcon2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + path + ";Extended Properties=Excel 12.0;";
            OleDbConnection conn2 = new OleDbConnection(pathcon2);
            da2 = new OleDbDataAdapter("Select * from [" + patchSheet + "$] ", conn2);
            dt[2] = new System.Data.DataTable();
            da2.Fill(dt[2]);
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dt[3] = new System.Data.DataTable();
            view[0] = new DataView(dt[2]);
            dt[3] = view[0].ToTable("dt[3]", false, "Component_name");

            if (count == 0)
                foreach (DataRow row in dt[3].Rows)
                {
                    comboBox1.Items.Add(row["Component_name"]);

                }
            count++;
            for (int i = 0; i < 10; i++)
            {
                if (comboBox1.SelectedIndex == i)
                {
                    comboBox2.SelectedIndex = i;
                    break;
                }
            }
        }

        private void comboBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dt[4] = new System.Data.DataTable();
            view[1] = new DataView(dt[2]);
            dt[4] = view[1].ToTable("dt[4]", false, "Component_name", "Patch_Number_Allocation");

            if (count1 == 0)
                foreach (DataRow row in dt[4].Rows)
                {
                    comboBox2.Items.Add(row["Patch_Number_Allocation"]);

                }
            count1++;
            for (int i = 0; i < 10; i++)
            {
                if (comboBox2.SelectedIndex == i)
                {
                    comboBox1.SelectedIndex = i;

                    break;
                }
            }
            comboBox3SetData();
        }

        public void comboBox3SetData()
        {
            if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 0)
            {
                comboBox3.Items.Clear();
                comboBox3.Items.Insert(0, "RTD Version");
                comboBox3.SelectedIndex = 0;
                count2 = 0;
            }
            else if (comboBox3.SelectedIndex > 0) { }
            else if (comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0)
            {
                comboBox3.Items.Clear();

                dt[5] = new System.Data.DataTable();
                view[2] = new DataView(dt[1]);
                dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");

                comboBox3.Items.Clear();

                try
                {
                    string str = null, str1;
                    comboBox3.Items.Add("RTD Version");
                    comboBox3.SelectedIndex = 0;
                    foreach (DataRow row in dt[5].Rows)
                    {

                        str = row["Patch_name"].ToString();
                        str1 = comboBox2.SelectedItem.ToString();
                        string[] strArr = str.Split(' ');
                        int len = strArr.Length;
                        string[] strArr1 = str1.Split(' ');
                        string sub = strArr[len - 1].Substring(0, 2);
                        string sub1 = sub.Substring(1, 1);


                        if (sub.StartsWith(strArr1[0]))
                        {
                            if (strArr1[0] == "10")
                            {
                                comboBox3.Items.Add(row["Patch_name"]);
                            }
                            else if (sub.StartsWith("1"))
                            {
                                if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                                {
                                    comboBox3.Items.Add(row["Patch_name"]);
                                }
                            }

                            else
                            {
                                comboBox3.Items.Add(row["Patch_name"]);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    var excp1 = new ExcepWindow();
                    excp1.msg = ex.Message;
                    excp1.ShowDialog();
                }

            }
        }

        private void comboBox3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 0)
            {
                dt[6] = new System.Data.DataTable();
                view[3] = new DataView(dt[1]);
                dt[6] = view[3].ToTable("dt[6]", false, "Patch_name");

                if (count2 == 0)
                    foreach (DataRow row in dt[6].Rows)
                    {
                        comboBox3.Items.Add(row["Patch_name"]);
                    }
                count2++;
            }

            if (comboBox3.SelectedIndex > 0)
            {
                comboBox1_2SetData();
            }
        }

        public void comboBox1_2SetData()
        {
            dt[7] = new System.Data.DataTable();
            view[4] = new DataView(dt[2]);
            dt[7] = view[4].ToTable("dt[7]", false, "Component_name", "Patch_Number_Allocation");

            try
            {
                string str = null, str1;
                foreach (DataRow row in dt[7].Rows)
                {

                    str = row["Patch_Number_Allocation"].ToString();
                    str1 = comboBox3.SelectedItem.ToString();
                    string[] strArr = str.Split(' ');
                    string[] strArr1 = str1.Split(' ');
                    int len = strArr1.Length;
                    string sub = strArr1[len - 1].Substring(0, 2);
                    string sub1 = sub.Substring(1, 1);

                    if (sub.StartsWith(strArr[0]) || sub.StartsWith("7") || sub.StartsWith("x"))
                    {
                        if (sub.StartsWith("7") || sub.StartsWith("x"))
                        {
                            comboBox1.Items.Add("NA");
                            comboBox2.Items.Add("NA");
                            comboBox1.SelectedValue = "NA";
                            comboBox2.SelectedValue = "NA";
                        }
                        else if (strArr[0] == "10")
                        {
                            comboBox2.SelectedItem = row["Patch_Number_Allocation"];
                        }

                        else if (sub.StartsWith("1"))
                        {
                            if ((sub1.Contains("1")) || (sub1.Contains("2")) || (sub1.Contains("3")) || (sub1.Contains("4")) || (sub1.Contains("5")) || (sub1.Contains("6")) || (sub1.Contains("7")) || (sub1.Contains("8")) || (sub1.Contains("9")))
                            {
                                comboBox1.Items.Add("NA");
                                comboBox2.Items.Add("NA");
                                comboBox1.SelectedValue = "NA";
                                comboBox2.SelectedValue = "NA";
                            }
                            if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                            {
                                comboBox2.SelectedItem = row["Patch_Number_Allocation"];
                            }
                        }

                        else
                        {
                            comboBox2.SelectedItem = row["Patch_Number_Allocation"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                var excp2 = new ExcepWindow();
                excp2.msg = ex.Message;
                excp2.ShowDialog();
            }
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            /********************** RESULT FOUND*******************/
            try
            {
                var watch = System.Diagnostics.Stopwatch.StartNew();
                Resulttab.IsSelected = true;
                if (comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0 && comboBox3.SelectedIndex > 0)
                {
                    string item = comboBox3.SelectedItem.ToString();
                    dt[8] = new System.Data.DataTable();
                    dt[8] = dt[1].Select("Patch_name='" + item + "'").CopyToDataTable();
                    dataGrid_cmbodisp.ItemsSource = dt[8].DefaultView;
                    dataGrid_cmbodisp.CanUserAddRows = false;
                    dataGrid_cmbodisp.MinColumnWidth = 100;
                    dataGrid_cmbodisp.MaxColumnWidth = 250;
                    clear_all();
                }
                else if (comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0)
                {
                    dt[9] = dt[1].Clone();
                    for (int i = 1; i < comboBox3.Items.Count; i++)
                    {
                        comboBox3.SelectedIndex = i;
                        string item = comboBox3.SelectedItem.ToString();
                        DataRow[] rowsToCopy;
                        rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                        foreach (DataRow temp in rowsToCopy)
                        {
                            dt[9].ImportRow(temp);
                        }

                        dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                        dataGrid_cmbodisp.CanUserAddRows = false;
                        dataGrid_cmbodisp.MinColumnWidth = 100;
                        dataGrid_cmbodisp.MaxColumnWidth = 250;
                    }
                    comboBox3.SelectedIndex = 0;
                    clear_all();
                }
                else
                {
                        Logstab.IsSelected = true;
                        Resulttab.IsSelected = false;
                        var Selectobj = new ExcepWindow();
                        Selectobj.msg = "Provide some search options.";
                        Selectobj.ShowDialog();
                }

                if ((comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0 && comboBox3.SelectedIndex > 0) || (comboBox1.SelectedIndex > 0 && comboBox2.SelectedIndex > 0))
                {
                    watch.Stop();
                    var elapsedMs = watch.ElapsedMilliseconds;
                    //MessageBox.Show(elapsedMs.ToString());

                    logcount = dataGrid_cmbodisp.Items.Count;
                    if (logcount != 0)
                    {
                        logtxt = "Searching the RTD Database";
                        logfuncname = getCallFunName();
                        logtime = logobj.logSearch(logcount, logtxt, logfuncname, elapsedMs.ToString());
                        string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                        TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                        rangeOfWord.Text = s;
                        rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                        rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
                    }
                }

                if (dataGrid_cmbodisp.ItemsSource != null)
                {
                    Button_enable();
                }
            }
            catch (Exception ex1)
            {
                var excp3 = new ExcepWindow();
                excp3.msg = ex1.Message;
                excp3.ShowDialog();
            }
        }

        
        public void filterInit()
        {
            filterHeaderInit();
            if (customerItem.Visibility == System.Windows.Visibility.Visible)
            {
                customerInit();
            }
            statusInit();
            ownerInit();
            bugFeatureInit();
        }

        public void filterHeaderInit()
        {
            if (customerItem.Visibility == System.Windows.Visibility.Visible)
            {
                customerItem.Header = "Customer";
            }
            statusItem.Header = "Status";
            ownerItem.Header = "Owner";
            bugFeatureItem.Header = "Bug/Feature";
        }

        public void customerInit()
        {
            dt[10] = new System.Data.DataTable();
            view[5] = new DataView(dt[1]);
            dt[10] = view[5].ToTable(true, "Customer");

            foreach (DataRow row in dt[10].Rows)
            {
                if (((row["Customer"].ToString()) != "NA") && ((row["Customer"].ToString()) != ""))
                {
                    System.Windows.Controls.CheckBox cb = new CheckBox();
                    cb.Height = 16;
                    cb.HorizontalAlignment = HorizontalAlignment.Left;
                    cb.Name = "checkBox1";
                    cb.VerticalAlignment = VerticalAlignment.Top;
                    cb.Content = row["Customer"];
                    customerItemChildSp.Children.Add(cb);
                    cb.Click += new RoutedEventHandler(customerCheckBox_Checked);
                }
            }
        }

        protected void customerCheckBox_Checked(object sender, EventArgs e)
        {
            int counter = 0;
            foreach (CheckBox xx in customerItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    counter++;
                }
            }
            if (counter == 0)
                customerItem.Header = "Customer";
            else
                customerItem.Header = "Customer (" + counter + ")";
        }

        public void statusInit()
        {
            dt[11] = new System.Data.DataTable();
            view[6] = new DataView(dt[1]);
            dt[11] = view[6].ToTable(true, "status");

            foreach (DataRow row in dt[11].Rows)
            {
                if (((row["status"].ToString()) != "NA") && ((row["status"].ToString()) != ""))
                {
                    System.Windows.Controls.CheckBox cb = new CheckBox();
                    cb.Height = 16;
                    cb.HorizontalAlignment = HorizontalAlignment.Left;
                    cb.Name = "checkBox1";
                    cb.VerticalAlignment = VerticalAlignment.Top;
                    cb.Content = row["status"];
                    statusItemChildSp.Children.Add(cb);
                    cb.Click += new RoutedEventHandler(statusCheckBox_Checked);
                }
            }
        }

        protected void statusCheckBox_Checked(object sender, EventArgs e)
        {
            int counter = 0;
            foreach (CheckBox xx in statusItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    counter++;
                }
            }
            if (counter == 0)
                statusItem.Header = "Status";
            else
                statusItem.Header = "Status (" + counter + ")";
        }

        public void ownerInit()
        {
            dt[12] = new System.Data.DataTable();
            view[7] = new DataView(dt[1]);
            dt[12] = view[7].ToTable(true, "owner");
            foreach (DataRow row in dt[12].Rows)
            {
                if (((row["owner"].ToString()) != "NA") && ((row["owner"].ToString()) != ""))
                {
                    System.Windows.Controls.CheckBox cb = new CheckBox();
                    cb.Height = 16;
                    cb.HorizontalAlignment = HorizontalAlignment.Left;
                    cb.Name = "checkBox1";
                    cb.VerticalAlignment = VerticalAlignment.Top;
                    cb.Content = row["owner"];
                    ownerItemChildSp.Children.Add(cb);
                    cb.Click += new RoutedEventHandler(ownerCheckBox_Checked);
                }
            }
        }
        protected void ownerCheckBox_Checked(object sender, EventArgs e)
        {
            int counter = 0;
            foreach (CheckBox xx in ownerItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    counter++;
                }
            }
            if (counter == 0)
                ownerItem.Header = "Owner";
            else
                ownerItem.Header = "Owner (" + counter + ")";
        }

        public void bugFeatureInit()
        {
            dt[13] = new System.Data.DataTable();
            view[8] = new DataView(dt[1]);
            dt[13] = view[8].ToTable(true, "Bug_Feature_or_both");
            foreach (DataRow row in dt[13].Rows)
            {
                if (((row["Bug_Feature_or_both"].ToString()) != "NA") && ((row["Bug_Feature_or_both"].ToString()) != ""))
                {
                    System.Windows.Controls.CheckBox cb = new CheckBox();
                    cb.Height = 16;
                    cb.HorizontalAlignment = HorizontalAlignment.Left;
                    cb.Name = "checkBox1";
                    cb.VerticalAlignment = VerticalAlignment.Top;
                    cb.Content = row["Bug_Feature_or_both"];
                    bugFeatureItemChildSp.Children.Add(cb);
                    cb.Click += new RoutedEventHandler(bugFeatureCheckBox_Checked);
                }
            }
        }

        protected void bugFeatureCheckBox_Checked(object sender, EventArgs e)
        {
            int counter = 0;
            foreach (CheckBox xx in bugFeatureItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    counter++;
                }
            }
            if (counter == 0)
                bugFeatureItem.Header = "Bug/Feature";
            else
                bugFeatureItem.Header = "Bug/Feature (" + counter + ")";
        }


        private void Filterbtn_Click(object sender, RoutedEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            dataGrid_cmbodisp.ItemsSource = null;
            int ct = 0;
            if (customerItem.Visibility == System.Windows.Visibility.Visible)
            {
                ct = customerFilter();
            }
            int ct1 = statusFilter(ct);
            int ct2 = ownerFilter(ct1);
            int ct3 = bugFeatureFilter(ct2);


            if (ct == 0 && ct1 == 0 && ct2 == 0 && ct3 == 0)
            {
                DataTable dd = new DataTable();
                dd.Columns.Add("Click the items to filter...");
                dataGrid_cmbodisp.ItemsSource = null;
                dataGrid_cmbodisp.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
                dataGrid_cmbodisp.ItemsSource = dd.DefaultView;
                Button_disable();
            }

            Resulttab.IsSelected = true;

            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Filtering from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logFilter(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }
       

        public int customerFilter()
        {
            string[] customerArray = new string[customerItemChildSp.Children.Count];
            int init = 0,ct=0;
            dt[14] = dt[1].Clone();            
            foreach (CheckBox xx in customerItemChildSp.Children)
            {
                string childname = null;
                if (xx.IsChecked == true)
                {
                    childname = xx.Content.ToString();
                    customerArray[init] = childname;
                    init++;
                    ct++;
                }
            }

            for (int i = 0; i < customerArray.Length; i++)
            {
                if (customerArray[i] != null)
                {
                    string item = customerArray[i];
                    DataRow[] rowsToCopy;
                    rowsToCopy = dt[1].Select("Customer='" + item + "'");
                    foreach (DataRow temp in rowsToCopy)
                    {
                        dt[14].ImportRow(temp);
                    }
                }
            }
            return ct;
            
        }


        public int statusFilter(int ct)
        {
            string[] statusArray = new string[statusItemChildSp.Children.Count];
            int init = 0, ct1 = 0;

            if (ct != 0)
                dt[15] = dt[14].Clone();
            else
            {
                dt[15] = dt[1].Clone();
                dt[14] = dt[1];
            }
           
            foreach (CheckBox xx in statusItemChildSp.Children)
            {
                string childname = null;
                if (xx.IsChecked == true)
                {
                    childname = xx.Content.ToString();
                    statusArray[init] = childname;
                    init++;
                    ct1++;
                }
            }

            for (int i = 0; i < statusArray.Length; i++)
            {
                if (statusArray[i] != null)
                {
                    string item = statusArray[i];
                    DataRow[] rowsToCopy;
                    rowsToCopy = dt[14].Select("status='" + item + "'");
                    foreach (DataRow temp in rowsToCopy)
                    {
                        dt[15].ImportRow(temp);
                    }
                }
            }
            return ct1;
            
        }


        public int ownerFilter(int ct1)
        {
            string[] ownerArray = new string[ownerItemChildSp.Children.Count];
            int init = 0, ct2 = 0;

            if (ct1 != 0)
                dt[16] = dt[15].Clone();
            else
            {
                dt[16] = dt[14].Clone();
                dt[15] = dt[14];
            }
            
            foreach (CheckBox xx in ownerItemChildSp.Children)
            {
                string childname = null;
                if (xx.IsChecked == true)
                {
                    childname = xx.Content.ToString();
                    ownerArray[init] = childname;
                    init++;
                    ct2++;
                }
            }

            for (int i = 0; i < ownerArray.Length; i++)
            {
                if (ownerArray[i] != null)
                {
                    string item = ownerArray[i];
                    DataRow[] rowsToCopy;
                    rowsToCopy = dt[15].Select("owner='" + item + "'");
                    foreach (DataRow temp in rowsToCopy)
                    {
                        dt[16].ImportRow(temp);
                    }
                }
            }
            return ct2;
        }


        public int bugFeatureFilter(int ct2)
        {
            string[] bugFeatureArray = new string[bugFeatureItemChildSp.Children.Count];
            int init = 0, ct3 = 0;

            if (ct2 != 0)
                dt[17] = dt[16].Clone();
            else
            {
                dt[17] = dt[15].Clone();
                dt[16] = dt[15];
            }

            foreach (CheckBox xx in bugFeatureItemChildSp.Children)
            {

                string childname = null;
                if (xx.IsChecked == true)
                {
                    childname = xx.Content.ToString();
                    bugFeatureArray[init] = childname;
                    init++;
                    ct3++;
                }
            }
            if (ct3 != 0)
            {
                for (int i = 0; i < bugFeatureArray.Length; i++)
                {
                    if (bugFeatureArray[i] != null)
                    {
                        string item = bugFeatureArray[i];
                        DataRow[] rowsToCopy;
                        rowsToCopy = dt[16].Select("Bug_Feature_or_both='" + item + "'");
                        foreach (DataRow temp in rowsToCopy)
                        {
                            dt[17].ImportRow(temp);
                        }
                    }
                }
                if (dt[17].Rows.Count != 0)
                {
                    dataGrid_cmbodisp.ItemsSource = dt[17].DefaultView;
                    dataGrid_cmbodisp.CanUserAddRows = false;
                    dataGrid_cmbodisp.MinColumnWidth = 100;
                    dataGrid_cmbodisp.MaxColumnWidth = 250;
                    if (dataGrid_cmbodisp.ItemsSource != null)
                    {
                        Button_enable();
                    }
                }
                else
                {
                    DataTable dd = new DataTable();
                    dd.Columns.Add("No Results Found...");
                    logtxt = "No Results found on Filtering RTD Database";
                    logfuncname = getCallFunName();
                    logtime = logobj.logFilter1(logtxt, logfuncname);
                    string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt);

                    TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                    rangeOfWord.Text = s;
                    rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                    rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
                    dataGrid_cmbodisp.ItemsSource = null;
                    dataGrid_cmbodisp.ItemsSource = dd.DefaultView;
                    Button_disable();
                }
            }
            else
            {
                if (dt[16].Rows.Count != 0)
                {
                    dataGrid_cmbodisp.ItemsSource = dt[16].DefaultView;
                    dataGrid_cmbodisp.CanUserAddRows = false;
                    dataGrid_cmbodisp.MinColumnWidth = 100;
                    dataGrid_cmbodisp.MaxColumnWidth = 250;
                    if (dataGrid_cmbodisp.ItemsSource != null)
                    {
                        Button_enable();
                    }
                }
                else
                {
                    DataTable dd = new DataTable();
                    dd.Columns.Add("No Results Found...");
                    logtxt = "No Results found on Filtering RTD Database";
                    logfuncname = getCallFunName();
                    logtime = logobj.logFilter1(logtxt, logfuncname);
                    string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt);

                    TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                    rangeOfWord.Text = s;
                    rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                    rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
                    dataGrid_cmbodisp.ItemsSource = null;
                    dataGrid_cmbodisp.ItemsSource = dd.DefaultView;
                    Button_disable();
                }
            }
            return ct3;
        }


        private void Aboutbtn_Click(object sender, RoutedEventArgs e)
        {
            About ab = new About();
            ab.ShowDialog();
        }

        private void Helpbtn_Click(object sender, RoutedEventArgs e)
        {
            Help h = new Help();
            h.ShowDialog();
        }

        private void Feedbackbtn_Click(object sender, RoutedEventArgs e)
        {
            Feedback fb = new Feedback();
            fb.ShowDialog();
            if (fb.Fdbk_tbk.Text != "" || fb.Attach_path.Text != "")
            {
                string s = fb.s;
                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
            else 
            {
                fb.Close();
            }
        }

        private void Series1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected= true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");

            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series1.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("1"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }

            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 1 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series2_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series2.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("2"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 2 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series3_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series3.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("3"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 3 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series4_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series4.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("4"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 4 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series5_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series5.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("5"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 5 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series6_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series6.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("6"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 6 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series8_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series8.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("8"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 8 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series9_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series9.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (sub.StartsWith("9"))
                    {
                        if (!(sub1.Contains("0")) && !(sub1.Contains("1")) && !(sub1.Contains("2")) && !(sub1.Contains("3")) && !(sub1.Contains("4")) && !(sub1.Contains("5")) && !(sub1.Contains("6")) && !(sub1.Contains("7")) && !(sub1.Contains("8")) && !(sub1.Contains("9")))
                        {
                            ll.Items.Add(row["Patch_name"]);
                        }
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }

            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 9 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }

        private void Series10_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Resulttab.IsSelected = true;
            Button_enable();
            dt[5] = new System.Data.DataTable();
            view[2] = new DataView(dt[1]);
            dt[5] = view[2].ToTable("dt[5]", false, "Patch_name");
            string str = null, str1;
            ListBox ll = new ListBox();
            foreach (DataRow row in dt[5].Rows)
            {
                str = row["Patch_name"].ToString();
                str1 = Series10.Content.ToString();

                string[] strArr = str.Split(' ');
                int len = strArr.Length;
                string[] strArr1 = str1.Split(' ');
                string sub = strArr[len - 1].Substring(0, 2);
                string sub1 = sub.Substring(1, 1);

                if (sub.StartsWith(strArr1[0]))
                {
                    if (strArr1[0] == "10")
                    {
                        ll.Items.Add(row["Patch_name"]);
                    }
                }
            }

            dt[9] = dt[1].Clone();
            //MessageBox.Show(ll.Items.Count.ToString());
            for (int i = 0; i < ll.Items.Count; i++)
            {
                ll.SelectedIndex = i;
                string item = ll.SelectedItem.ToString();
                DataRow[] rowsToCopy;
                rowsToCopy = dt[1].Select("Patch_name='" + item + "'");
                foreach (DataRow temp in rowsToCopy)
                {
                    dt[9].ImportRow(temp);
                }
                dataGrid_cmbodisp.ItemsSource = dt[9].DefaultView;
                dataGrid_cmbodisp.CanUserAddRows = false;
                dataGrid_cmbodisp.MinColumnWidth = 100;
                dataGrid_cmbodisp.MaxColumnWidth = 250;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            //MessageBox.Show(elapsedMs.ToString());

            logcount = dataGrid_cmbodisp.Items.Count;
            if (logcount != 0)
            {
                logtxt = "Patch Series 10 is Searched from RTD Database";
                logfuncname = getCallFunName();
                logtime = logobj.logSeries(logcount, logtxt, logfuncname, elapsedMs.ToString());
                string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                rangeOfWord.Text = s;
                rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
            }
        }


        private void ClearAll_btn_Click(object sender, RoutedEventArgs e)
        {
            dataGrid_cmbodisp.ItemsSource = null;
            Logs.Document.Blocks.Clear();
            if (System.IO.File.Exists(path))
                clear_all();
            Button_disable();
        }

        private void Export_btn_Click(object sender, RoutedEventArgs e)
        {
            if (Resulttab.IsSelected == true)
            {
                if (dataGrid_cmbodisp.ItemsSource != null)
                {
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                    Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                    worksheet = workbook.Sheets["Sheet1"];
                    worksheet = workbook.ActiveSheet;
                    worksheet.Name = "Exported data";


                    for (int i = 1; i < dataGrid_cmbodisp.Columns.Count + 1; i++)
                    {
                        worksheet.Cells[1, i] = dataGrid_cmbodisp.Columns[i - 1].Header;
                    }

                    for (int i = 0; i < dataGrid_cmbodisp.Items.Count; i++)
                    {
                        for (int j = 0; j < dataGrid_cmbodisp.Columns.Count; j++)
                        {
                            worksheet.Cells[i + 2, j + 1] = (dataGrid_cmbodisp.Items[i] as DataRowView).Row.ItemArray[j].ToString();
                        }
                    }

                    worksheet.Columns.AutoFit();
                    worksheet.Rows.AutoFit();

                    watch.Stop();
                    var elapsedMs = watch.ElapsedMilliseconds;
                    //MessageBox.Show(elapsedMs.ToString());

                    var sfd = new SaveFileDialog();
                    sfd.FileName = "Untitled";
                    sfd.Filter = "Excel File (*.xlsx)|*.xlsx|Excel File (*.xls)|*.xls|All files (*.*)|*.*";
                    //sfd.DefaultExt = ".xlsx";
                    if (sfd.ShowDialog() == true)
                    {
                        workbook.SaveAs(sfd.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        string logPath = System.IO.Path.GetDirectoryName(sfd.FileName);
                        logcount = dataGrid_cmbodisp.Items.Count;
                        logtxt = "Exporting the Results to " + logPath;
                        logfuncname = getCallFunName();
                        logtime = logobj.logExportdg(logcount, logtxt, logfuncname, elapsedMs.ToString());
                        string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt + " and No of Entries found: " + logcount);

                        TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                        rangeOfWord.Text = s;
                        rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                        rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
                    }
                    else
                    {
                        workbook.Close(false, Type.Missing, Type.Missing);
                    }
                    app.Quit();
                }
            }
            else {

                if (Logs.Document.Blocks.Count != 0)
                {
                    string exppath = @"C:\RTDLogs\Userlogs.txt";
                    TextRange range;
                    FileStream fStream;
                    range = new TextRange(Logs.Document.ContentStart, Logs.Document.ContentEnd);
                    fStream = new FileStream(exppath, FileMode.Create);
                    range.Save(fStream, DataFormats.Text);
                    fStream.Close();

                    logtxt = "Logs exported to " + exppath;
                    logfuncname = getCallFunName();
                    logtime = logobj.logExportlogs(logtxt, logfuncname);
                    string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt);

                    TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
                    rangeOfWord.Text = s;
                    rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
                    rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);
                }
                
            }
        }

        private void Expandviewtbn_Click(object sender, RoutedEventArgs e)
        {
            if (Resulttab.IsSelected == true)
            {
                var obj2 = new Filtered_data();
                obj2.dataGrid1.ItemsSource = dataGrid_cmbodisp.Items;
                obj2.ShowDialog();
            }
            
        }

        private void buttonMinimize_Click(object sender, RoutedEventArgs e)
        {
            // Set Window State to Minimized
            this.WindowState = WindowState.Minimized;
        }

        

        private void buttonClose_Click(object sender, RoutedEventArgs e)
        {
            // Shutdown current application
            Application.Current.Shutdown();
        }

        private void labelApplicationTitle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Maximize or restore window if left button is clicked two times
            // Allow window to be dragged if left button is clicked and hold only one time
            if (e.ChangedButton == MouseButton.Left)
            {
                if (e.ClickCount == 2)
                {
                    this.WindowState = this.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
                }
                else
                {
                    Application.Current.MainWindow.DragMove();
                }
            }
        }

        private void Resetbtn_Click(object sender, RoutedEventArgs e)
        {
            dataGrid_cmbodisp.ItemsSource = null;
            Logstab.IsSelected = true;
            foreach (CheckBox xx in customerItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    xx.IsChecked = false;
                }
            }
            foreach (CheckBox xx in statusItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    xx.IsChecked = false;
                }
            }
            foreach (CheckBox xx in ownerItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    xx.IsChecked = false;
                }
            }
            foreach (CheckBox xx in bugFeatureItemChildSp.Children)
            {
                if (xx.IsChecked == true)
                {
                    xx.IsChecked = false;
                }
            }
            filterHeaderInit();
        }

        private void FCtrl_mode(object sender, RoutedEventArgs e)
        {
            string h = WindowsIdentity.GetCurrent().Name;
            string[] strArr = h.Split('\\');
            string sub = strArr[1];
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load("E:\\xml parsing exs\\6\\RTDmodes.xml");
            XmlNodeList nodeList = xmldoc.SelectNodes("/Userdetails/User[Name='" + sub + "']");
            string sql = "";
            foreach (XmlNode node in nodeList)
            {
                if (node["Mode"].Attributes["FCntrl"].Value == "true")
                {
                    //FCtrl_modebtn.Visibility = System.Windows.Visibility.Visible;
                    customerItem.Visibility = System.Windows.Visibility.Visible;
                    sql = node["FCtrlsql"].Attributes["qry"].Value;
                    if (node["Perm"].Attributes["Write"].Value == "true")
                    {
                        dataGrid_disp.IsReadOnly = false;
                        dataGrid_cmbodisp.IsReadOnly = false;
                    }
                }
            }

            logtxt = "Switching to Full Control Mode";
            logfuncname = getCallFunName();
            logtime = logobj.logSwitch(logtxt, logfuncname);
            string s = (Environment.NewLine + "[ " + logtime + " ] " + logtxt);

            TextRange rangeOfWord = new TextRange(Logs.Document.ContentEnd, Logs.Document.ContentEnd);
            rangeOfWord.Text = s;
            rangeOfWord.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF293955")));
            rangeOfWord.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Regular);

            openSheetLoad(sql,1);
            Fetchtab.IsSelected = true;
            FCtrl_modebtn.IsEnabled = false;
        }
       
    }
}
