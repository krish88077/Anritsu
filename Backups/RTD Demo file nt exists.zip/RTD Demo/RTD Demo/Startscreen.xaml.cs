﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


using System.Windows.Threading;
using System.Threading;

namespace RTD_Demo
{
    /// <summary>
    /// Interaction logic for Startscreen.xaml
    /// </summary>
    public partial class Startscreen : Window
    {
        public Startscreen()
        {
            InitializeComponent();
        }
        DispatcherTimer timer = null;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            StartTimer();
        }

        void StartTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(4);
            timer.Tick += new EventHandler(timer_Elapsed);
            timer.Start();
        }

        void timer_Elapsed(object sender, EventArgs e)
        {
            timer.Stop();
            this.Close();
        }
    }
}
