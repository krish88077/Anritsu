﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace RTD_Demo
{
    /// <summary>
    /// Interaction logic for LoadExcel.xaml
    /// </summary>
    public partial class LoadExcel : Window
    {
        public LoadExcel()
        {
            InitializeComponent();
        }
        public string patht = "";

        private void Browsebtn_Click(object sender, RoutedEventArgs e)
        {
             OpenFileDialog oo = new OpenFileDialog();
             oo.Filter = "Excel Files (*.xlsx)|*.xlsx";
             oo.DefaultExt = ".xlsx";
             oo.AddExtension = true;
            
            string fileName = "";
            
                if (oo.ShowDialog() == true)
                {

                    fileName = oo.FileName;
                    Pathtxtbx.Text = fileName;

                }
        }

        private void Loadbtn_Click(object sender, RoutedEventArgs e)
        {
            if (Pathtxtbx.Text != "")
            {
                patht = Pathtxtbx.Text;
                this.Close();
            }
            else
            {
                var ldxlobj = new ExcepWindow();
                ldxlobj.msg = "Browse for a file first";
                ldxlobj.ShowDialog();
            }
        }

        private void Cancelbtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void buttonClose_Click(object sender, RoutedEventArgs e)
        {

            this.Close();
        }

    }
}
